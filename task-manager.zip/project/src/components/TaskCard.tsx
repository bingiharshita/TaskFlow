import React, { useState } from 'react';
import { Edit2, Trash2, Check, X, Calendar } from 'lucide-react';
import { Task } from '../types/Task';

interface TaskCardProps {
  task: Task;
  onUpdate: (task: Task) => void;
  onDelete: (id: string) => void;
}

const priorityConfig = {
  high: {
    bg: 'bg-gradient-to-r from-red-50 to-red-100',
    border: 'border-red-200',
    badge: 'bg-red-500 text-white',
    text: 'text-red-700',
    ring: 'ring-red-200'
  },
  medium: {
    bg: 'bg-gradient-to-r from-orange-50 to-orange-100',
    border: 'border-orange-200',
    badge: 'bg-orange-500 text-white',
    text: 'text-orange-700',
    ring: 'ring-orange-200'
  },
  low: {
    bg: 'bg-gradient-to-r from-blue-50 to-blue-100',
    border: 'border-blue-200',
    badge: 'bg-blue-500 text-white',
    text: 'text-blue-700',
    ring: 'ring-blue-200'
  }
};

export const TaskCard: React.FC<TaskCardProps> = ({ task, onUpdate, onDelete }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    title: task.title,
    description: task.description,
    priority: task.priority
  });

  const config = priorityConfig[task.priority];

  const handleSave = () => {
    onUpdate({
      ...task,
      ...editForm,
      updatedAt: new Date()
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditForm({
      title: task.title,
      description: task.description,
      priority: task.priority
    });
    setIsEditing(false);
  };

  const toggleComplete = () => {
    onUpdate({
      ...task,
      completed: !task.completed,
      updatedAt: new Date()
    });
  };

  return (
    <div className={`${config.bg} ${config.border} border rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-200 group relative overflow-hidden`}>
      {/* Priority indicator */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-current to-transparent opacity-30"></div>
      
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={toggleComplete}
            className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all duration-200 ${
              task.completed
                ? 'bg-green-500 border-green-500 text-white'
                : `border-gray-300 hover:${config.ring} hover:ring-2`
            }`}
          >
            {task.completed && <Check size={14} />}
          </button>
          <span className={`${config.badge} px-3 py-1 rounded-full text-xs font-medium uppercase tracking-wide`}>
            {task.priority}
          </span>
        </div>
        
        <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button
            onClick={() => setIsEditing(true)}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-white/50 rounded-lg transition-colors duration-200"
          >
            <Edit2 size={16} />
          </button>
          <button
            onClick={() => onDelete(task.id)}
            className="p-2 text-gray-400 hover:text-red-500 hover:bg-white/50 rounded-lg transition-colors duration-200"
          >
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      {isEditing ? (
        <div className="space-y-4">
          <input
            type="text"
            value={editForm.title}
            onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-200 focus:border-blue-400 outline-none transition-colors"
            placeholder="Task title"
          />
          <textarea
            value={editForm.description}
            onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-200 focus:border-blue-400 outline-none transition-colors resize-none"
            placeholder="Task description"
            rows={3}
          />
          <select
            value={editForm.priority}
            onChange={(e) => setEditForm({ ...editForm, priority: e.target.value as 'high' | 'medium' | 'low' })}
            className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-200 focus:border-blue-400 outline-none transition-colors"
          >
            <option value="high">High Priority</option>
            <option value="medium">Medium Priority</option>
            <option value="low">Low Priority</option>
          </select>
          <div className="flex gap-2">
            <button
              onClick={handleSave}
              className="flex-1 bg-green-500 text-white py-2 px-4 rounded-lg hover:bg-green-600 transition-colors duration-200 font-medium"
            >
              Save
            </button>
            <button
              onClick={handleCancel}
              className="flex-1 bg-gray-100 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-200 transition-colors duration-200 font-medium"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <div className={task.completed ? 'opacity-60' : ''}>
          <h3 className={`text-lg font-semibold mb-2 ${task.completed ? 'line-through' : ''} transition-all duration-200`}>
            {task.title}
          </h3>
          {task.description && (
            <p className={`text-gray-600 mb-4 ${task.completed ? 'line-through' : ''} transition-all duration-200`}>
              {task.description}
            </p>
          )}
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <Calendar size={12} />
            <span>Created {new Date(task.createdAt).toLocaleDateString()}</span>
          </div>
        </div>
      )}
    </div>
  );
};